// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import {
  getStorage,
  ref as storageRef,
  getDownloadURL,
} from 'firebase/storage';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyCvzHYmWJAIFgb1kysu0-LFxyXRacFak4A',
  authDomain: 'recipetest-c2329.firebaseapp.com',
  projectId: 'recipetest-c2329',
  storageBucket: 'recipetest-c2329.appspot.com',
  messagingSenderId: '526532946925',
  appId: '1:526532946925:web:118a60e49a176d87d095e4',
};

export const DATABASE_URL = `https://${firebaseConfig.projectId}-default-rtdb.europe-west1.firebasedatabase.app`;

// Initialize Firebase
export const firebaseApp = initializeApp(firebaseConfig);

export const firebaseDatabase = getDatabase(firebaseApp, DATABASE_URL);

export const RECIPES_PROPERTY_ROOT = 'recipes';

export const fireStorageDownloadUrl = (
  path: string,
  cb?: (url?: string) => void,
): Promise<string | undefined> | undefined => {
  const firebaseStorage = getStorage(firebaseApp);
  const sRef = storageRef(firebaseStorage, path);
  if (cb) {
    getDownloadURL(sRef)
      .then(url => cb(url))
      .catch(_ => cb());
    return;
  }
  return new Promise(resolve => {
    getDownloadURL(sRef)
      .then(url => resolve(url))
      .catch(_ => resolve(undefined));
  });
};
